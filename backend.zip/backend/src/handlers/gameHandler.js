/*
 * [2025-07-23] João Neto:
 * Semana 3: Atividade 7: Começar jogo quando todos estiverem prontos
 */
const gameService = require('../services/gameService');

exports.create = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    const result = await gameService.createGame(req.body, token);
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.join = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    const result = await gameService.joinGame(req.body, token);
    res.status(200).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.start = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    const result = await gameService.startGame(req.body, token);
    res.status(200).json(result);
  } catch (err) {
    res.status(403).json({ error: err.message });
  }
};