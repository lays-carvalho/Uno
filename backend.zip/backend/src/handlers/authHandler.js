/*
 * [2025-07-23] João Neto:
 * Semana 3: Atividade 4: Obter perfil do usuário
 */
const authService = require('../services/authService');

exports.register = async (req, res) => {
  try {
    const result = await authService.registerUser(req.body);
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const result = await authService.loginUser(req.body);
    res.status(200).json(result);
  } catch (err) {
    res.status(401).json({ error: err.message });
  }
};

exports.logout = async (req, res) => {
  res.status(200).json(await authService.logoutUser());
};

exports.profile = async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    const result = await authService.getProfile(token);
    res.status(200).json(result);
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
};