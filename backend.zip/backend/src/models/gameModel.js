/*
 * [2025-07-23] João Neto:
 * Semana 3: Atividade 5: Criar novo jogo
 */
const gameSchema = new mongoose.Schema({
  name: { type: String, required: true },
  rules: { type: String },
  creatorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  started: { type: Boolean, default: false },
  players: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
});

module.exports = mongoose.model('Game', gameSchema);